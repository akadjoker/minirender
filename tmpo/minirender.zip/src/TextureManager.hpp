#pragma once
#include "Texture.hpp"
#include <unordered_map>
#include <string>
#include <iostream>

class TextureManager
{
public:
    static TextureManager &instance()
    {
        static TextureManager inst;
        return inst;
    }

    ~TextureManager() { clear(); }

    Texture *load(const std::string &path)
    {
        auto it = textures.find(path);
        if (it != textures.end())
            return it->second;

        Texture *tex = new Texture();
        if (!tex->load(path))
        {
            std::cerr << "[TextureManager] Failed to load: " << path << "\n";
            delete tex;
            return nullptr;
        }

        textures[path] = tex;
        return tex;
    }

    Texture *get(const std::string &path)
    {
        auto it = textures.find(path);
        return it != textures.end() ? it->second : nullptr;
    }

    void destroy(const std::string &path)
    {
        auto it = textures.find(path);
        if (it != textures.end())
        {
            delete it->second;
            textures.erase(it);
        }
    }

    void clear()
    {
        for (auto &[path, tex] : textures)
            delete tex;
        textures.clear();
    }

    int count() const { return (int)textures.size(); }

private:
    std::unordered_map<std::string, Texture *> textures;
};
