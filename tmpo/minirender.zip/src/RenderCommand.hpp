// RenderCommand.hpp
#pragma once
#include <glm/glm.hpp>
#include <cstdint>

class Mesh;
class Material;

struct RenderCommand
{
    Mesh *mesh = nullptr;
    Material *material = nullptr;
    glm::mat4 transform = glm::mat4(1.0f);
    bool castShadows = true;

    // Chave calculada uma vez no submit
    uint64_t sortKey = 0;
};
