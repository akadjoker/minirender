#pragma once
#include "Material.hpp"
#include <unordered_map>

class MaterialManager
{
public:
    static MaterialManager &instance()
    {
        static MaterialManager inst;
        return inst;
    }

    Material *create(const std::string &name)
    {
        auto *mat = new Material(name);
        materials[name] = mat;
        return mat;
    }

    Material *get(const std::string &name)
    {
        auto it = materials.find(name);
        return it != materials.end() ? it->second : nullptr;
    }

    void clear()
    {
        for (auto &[n, m] : materials)
            delete m;
        materials.clear();
    }

    ~MaterialManager() { clear(); }

private:
    std::unordered_map<std::string, Material *> materials;
};
