#pragma once
#include "Node.hpp"
#include "Camera.hpp"
#include "RenderQueue.hpp"
#include <vector>

class Scene
{
public:
    Camera camera;

    Node *createNode(const std::string &name)
    {
        Node *n = new Node();
        n->name = name;
        nodes.push_back(n);
        return n;
    }

    void collectCommands(RenderQueue *queue)
    {
        for (auto *n : nodes)
            n->submit(queue);
    }

    void clear()
    {
        for (auto *n : nodes)
            delete n;
        nodes.clear();
    }

    ~Scene() { clear(); }

private:
    std::vector<Node *> nodes;
};
