#pragma once
#include "Config.hpp"
#include "Opengl.hpp"
#include "Math.hpp"
#include "Material.hpp"
 
#define GLM_ENABLE_EXPERIMENTAL
#include <glm/glm.hpp>
#include <vector>
#include <cstdint>
#include <cstring>
#include <cassert>
#include <string>
#include <unordered_set>

class Shader;
class Animation;

// ============================================================
//  Vertex — static geometry  (48 bytes)
// ============================================================
struct Vertex
{
    glm::vec3 position; // 12 bytes
    glm::vec3 normal;   // 12 bytes
    glm::vec4 tangent;  // 16 bytes  (w = handedness)
    glm::vec2 uv;       //  8 bytes
};

// ============================================================
//  AnimatedVertex — skinned geometry  (80 bytes)
// ============================================================
struct AnimatedVertex
{
    glm::vec3 position;
    glm::vec3 normal;
    glm::vec4 tangent;
    glm::vec2 uv;
    glm::ivec4 boneIds = {0, 0, 0, 0};
    glm::vec4 boneWeights = {0.0f, 0.0f, 0.0f, 0.0f};
};

// ============================================================
//  InstanceBuffer — per-instance model matrices (mat4)
//  Attach to a MeshBuffer VAO; locations 6-9 hold the 4 columns.
//
//  Usage:
//    InstanceBuffer ib;
//    ib.resize(N);                    // allocate GPU buffer
//    ib.set(i, modelMatrix);          // fill per instance
//    ib.upload();                     // stream to GPU
//    mesh.attachInstances(&ib);       // bind divisor 1 to VAO
//    mesh.drawInstanced(ib.count());  // glDrawElementsInstanced
// ============================================================
struct InstanceBuffer
{
    std::vector<glm::mat4> matrices;   // CPU-side data
    GLuint vbo = 0;
    bool   dynamic = true;

    // (Re)allocate and upload all matrices to the GPU.
    void upload();

    // Stream updated matrices without reallocation (same size).
    void update();

    void resize(int n)  { matrices.resize(n, glm::mat4(1.f)); }
    void set(int i, const glm::mat4 &m) { matrices[i] = m; }
    int  count() const  { return (int)matrices.size(); }

    void free();

    InstanceBuffer() = default;
    InstanceBuffer(const InstanceBuffer &) = delete;
    InstanceBuffer &operator=(const InstanceBuffer &) = delete;
    ~InstanceBuffer() { free(); }
};

// ============================================================
//  IDrawable — interface for anything that can be rendered
// ============================================================
class IDrawable
{
public:
    virtual ~IDrawable() = default;
    virtual void draw() const = 0;
    virtual void drawRange(uint32_t start, uint32_t count) const = 0;
    // Instanced draw — default no-op; MeshBuffer implements it.
    virtual void drawInstanced(int instanceCount) const {}
    virtual void drawRangeInstanced(uint32_t start, uint32_t count, int instanceCount) const {}
    virtual BoundingBox getAABB() const = 0;
    virtual int vertexCount() const = 0;
    virtual int indexCount() const = 0;
    // Sends bone matrices to shader (no-op for static meshes)
    virtual void applyBoneMatrices(Shader *sh) const {}
    virtual bool isSkinned() const { return false; }
};

// ============================================================
//  MeshBuffer — static
// ============================================================
struct MeshBuffer : public IDrawable
{
    std::vector<Vertex> vertices;
    std::vector<uint32_t> indices;
    GLuint vao = 0, vbo = 0, ibo = 0;
    bool dynamic = false;
    GLenum mode = GL_TRIANGLES;
    BoundingBox aabb = {};     // optional — terrain/custom nodes fill this

    void upload();
    void update();
    void draw() const override;
    void drawRange(uint32_t start, uint32_t count) const override;

    // Attach an InstanceBuffer — binds its VBO into this VAO at locations 6-9
    // with divisor=1. Call once after upload().
    void attachInstances(InstanceBuffer *ib);

    // Draw N instances. Requires attachInstances() to have been called first.
    void drawInstanced(int instanceCount) const override;
    void drawRangeInstanced(uint32_t start, uint32_t count, int instanceCount) const override;

    void free();

    // IDrawable
    BoundingBox getAABB() const override { return aabb; }
    int vertexCount() const override { return (int)vertices.size(); }
    int indexCount() const override { return (int)indices.size(); }

    Vertex &operator[](int i) { return vertices[i]; }
    int count() const { return (int)vertices.size(); }

    MeshBuffer() = default;
    MeshBuffer(const MeshBuffer &) = delete;
    MeshBuffer &operator=(const MeshBuffer &) = delete;
    ~MeshBuffer() { free(); }
};

// ============================================================
//  AnimatedMeshBuffer — skinned
// ============================================================
struct AnimatedMeshBuffer : public IDrawable
{
    std::vector<AnimatedVertex> vertices;
    std::vector<uint32_t> indices;
    GLuint vao = 0, vbo = 0, ibo = 0;
    GLenum mode = GL_TRIANGLES;

    void upload();
    void draw() const override;
    void drawRange(uint32_t start, uint32_t count) const override;
    void free();

    // IDrawable
    BoundingBox getAABB() const override { return BoundingBox{}; }
    int vertexCount() const override { return (int)vertices.size(); }
    int indexCount() const override { return (int)indices.size(); }

    AnimatedVertex &operator[](int i) { return vertices[i]; }
    int count() const { return (int)vertices.size(); }

    AnimatedMeshBuffer() = default;
    AnimatedMeshBuffer(const AnimatedMeshBuffer &) = delete;
    AnimatedMeshBuffer &operator=(const AnimatedMeshBuffer &) = delete;
    ~AnimatedMeshBuffer() { free(); }
};

// ============================================================
//  TerrainVertex — 40 bytes, no tangent, two UV sets
//
//  loc 0  position  vec3   — world-space XYZ
//  loc 1  normal    vec3   — smooth shading normal
//  loc 2  uv        vec2   — base texture (scales with terrain)
//  loc 3  uv2       vec2   — detail texture (tiles rapidly)
//
//  Tangent is intentionally omitted: terrain normal-maps are
//  usually in object-space, and when tangent-space NM is needed
//  a TBN can be reconstructed in the vertex shader cheaply
//  (T = cross(normal, vec3(0,0,1)), B = cross(T, normal)).
// ============================================================
struct TerrainVertex
{
    glm::vec3 position; // 12 bytes
    glm::vec3 normal;   // 12 bytes
    glm::vec2 uv;       //  8 bytes — base tex
    glm::vec2 uv2;      //  8 bytes — detail tex
};

// ============================================================
//  TerrainBuffer
// ============================================================
struct TerrainBuffer : public IDrawable
{
    std::vector<TerrainVertex> vertices;
    std::vector<uint32_t>      indices;
    GLuint vao   = 0, vbo = 0, ibo = 0;
    bool   dynamic = false;
    GLenum mode    = GL_TRIANGLES;
    BoundingBox aabb = {};

    void upload();                              // static VBO + static IBO
    void allocateDynamicIndices(size_t maxCount);// static VBO + pre-alloc dynamic IBO
    void updateIndices(size_t count);            // glBufferSubData first `count` indices
    void update();
    void draw()          const override;
    void drawRange(uint32_t start, uint32_t count) const override;
    void free();

    // IDrawable
    BoundingBox getAABB()    const override { return aabb; }
    int vertexCount()        const override { return (int)vertices.size(); }
    int indexCount()         const override { return (int)indices.size(); }

    TerrainVertex &operator[](int i) { return vertices[i]; }
    int  count() const { return (int)vertices.size(); }

    TerrainBuffer() = default;
    TerrainBuffer(const TerrainBuffer &) = delete;
    TerrainBuffer &operator=(const TerrainBuffer &) = delete;
    ~TerrainBuffer() { free(); }
};

// ============================================================
//  ParticleVertex — 36 bytes, billboard quads
//
//  loc 0  position  vec3  — world-space XYZ  (built each frame)
//  loc 1  texCoord  vec2  — atlas UV
//  loc 2  color     vec4  — rgba tint + alpha
// ============================================================
struct ParticleVertex
{
    glm::vec3 position; // 12
    glm::vec2 texCoord; //  8
    glm::vec4 color;    // 16
};                      // 36 bytes total

// ============================================================
//  ParticleBuffer — dynamic VBO, pre-baked static IBO
// ============================================================
struct ParticleBuffer : public IDrawable
{
    std::vector<ParticleVertex> vertices;   // CPU-side, rebuilt each frame
    GLuint vao      = 0, vbo = 0, ibo = 0;
    int    capacity = 0;                    // max particles allocated on GPU

    // Call once: allocates VAO, dynamic VBO and static quad-index IBO.
    void allocate(int maxParticles);

    // Partial upload: only the first activeParticles*4 vertices.
    void uploadVertices(int activeParticles);

    void draw()      const override;
    void drawRange(uint32_t start, uint32_t count) const override;
    void free();

    // IDrawable
    BoundingBox getAABB()     const override { return BoundingBox{}; }
    int         vertexCount() const override { return (int)vertices.size(); }
    int         indexCount()  const override { return capacity * 6; }

    ParticleBuffer() = default;
    ParticleBuffer(const ParticleBuffer &) = delete;
    ParticleBuffer &operator=(const ParticleBuffer &) = delete;
    ~ParticleBuffer() { free(); }
};

// ============================================================
//  Surface — geometry slice + material slot
// ============================================================
struct Surface
{
    uint32_t index_start = 0;
    uint32_t index_count = 0;
    int material_index = 0; // index into MeshBase::materials[]
    BoundingBox aabb = {};
    Surface() = default;
    Surface(uint32_t start, uint32_t count, int mat)
        : index_start(start), index_count(count), material_index(mat) {}
};

// ============================================================
//  Bone
// ============================================================
struct Bone
{
    std::string name;
    glm::mat4 offset;    // inverse bind pose (model→bone space)
    glm::mat4 localPose; // rest pose in parent-local space (from file)
    int parent = -1;     // index into skeleton bone array (-1 = root)
};

// ============================================================
//  MeshBase<TBuffer> — shared data, buffer type varies
// ============================================================
template <typename TBuffer>
class MeshBase
{
public:
    std::string name;
    TBuffer buffer;
    BoundingBox aabb = {};
    std::vector<Surface> surfaces;
    std::vector<Material *> materials; // owned by mesh

    // ── Surfaces ──────────────────────────────────────────
    Surface &add_surface(uint32_t start, uint32_t count, int material_index = 0)
    {
        surfaces.push_back({start, count, material_index});
        return surfaces.back();
    }

    // ── Materials ─────────────────────────────────────────
    int add_material(Material *mat)
    {
        materials.push_back(mat);
        return (int)materials.size() - 1;
    }

    void set_material(int slot, Material *mat)
    {
        if (slot >= (int)materials.size())
            materials.resize(slot + 1, nullptr);
        materials[slot] = mat;
    }

    void release_materials()
    {
        std::unordered_set<Material *> uniqueMaterials;
        for (Material *mat : materials)
            if (mat)
                uniqueMaterials.insert(mat);
        for (Material *mat : uniqueMaterials)
            delete mat;
        materials.clear();
    }

    // ── AABB ──────────────────────────────────────────────
    void compute_aabb()
    {
        aabb = BoundingBox{};
        for (auto &v : buffer.vertices)
            aabb.expand(v.position);
    }

    void compute_surface_aabbs()
    {
        for (auto &surface : surfaces)
        {
            surface.aabb = BoundingBox{};

            const uint32_t start = surface.index_start;
            const uint32_t end = std::min<uint32_t>(surface.index_start + surface.index_count,
                                                    static_cast<uint32_t>(buffer.indices.size()));

            for (uint32_t i = start; i < end; ++i)
            {
                const uint32_t vertexIndex = buffer.indices[i];
                if (vertexIndex < static_cast<uint32_t>(buffer.vertices.size()))
                    surface.aabb.expand(buffer.vertices[vertexIndex].position);
            }
        }
    }

    void free()
    {
        buffer.free();
        release_materials();
    }

    ~MeshBase() { free(); }
};

// ============================================================
//  Mesh — static geometry
// ============================================================
class Mesh : public MeshBase<MeshBuffer>, public IDrawable
{
public:
    // Apply a matrix to all vertices in CPU memory (position, normal, tangent).
    // Call upload() afterwards to push changes to the GPU.
    void transform(const glm::mat4 &m);

    // Flip all normals (CPU side — requires upload() afterwards)
    void flip_normals();

    // Recalculate smooth normals from triangle geometry
    void compute_normals();

    // Compute tangents from UV layout (requires UVs and normals to be set first).
    // Fills Vertex::tangent.xyz; tangent.w = handedness (+1 or -1).
    void compute_tangents();

    // upload buffer + compute_aabb
    void upload();

    void draw() const override { buffer.draw(); }
    void drawRange(uint32_t s, uint32_t c) const override { buffer.drawRange(s, c); }
    BoundingBox getAABB() const override { return aabb; }
    int vertexCount() const override { return (int)buffer.vertices.size(); }
    int indexCount() const override { return (int)buffer.indices.size(); }

    // ── Picking ───────────────────────────────────────────────
    // worldRay in world space; model = world matrix of the owning node.
    // Phase 1: AABB reject.  Phase 2: Möller–Trumbore per triangle.
    // Returns best hit or hit==false if no intersection.
    PickResult pick(const Ray &worldRay, const glm::mat4 &model = glm::mat4(1.f)) const;

    // Embedded lightmap (optional, loaded from LMAP chunk in H3D)
    struct EmbeddedLightmap {
        int width = 0, height = 0, channels = 3;
        std::vector<uint8_t> pixels; // RGB
        bool empty() const { return pixels.empty(); }
    };
    EmbeddedLightmap lightmap;
};

// ============================================================
//  AnimatedMesh — skinned geometry
// ============================================================
class AnimatedMesh : public MeshBase<AnimatedMeshBuffer>, public IDrawable
{
public:
    // skeleton
    std::vector<Bone> bones;              // indexed by boneIds in AnimatedVertex
    std::vector<glm::mat4> finalMatrices; // updated each frame, sent to shader
    std::vector<Animation *> animations;  // owned by mesh

    // Compute tangents after loading (AnimatedVertex has same uv/normal/tangent layout)
    void compute_tangents();
    void releaseAnimations();
    BoundingBox computeSkinnedAABB() const;
    ~AnimatedMesh();

    // upload buffer + compute_aabb
    void upload();

    void draw() const override { buffer.draw(); }
    void drawRange(uint32_t s, uint32_t c) const override { buffer.drawRange(s, c); }
    BoundingBox getAABB() const override { return aabb; }
    int vertexCount() const override { return (int)buffer.vertices.size(); }
    int indexCount() const override { return (int)buffer.indices.size(); }
    void applyBoneMatrices(Shader *sh) const override;
    bool isSkinned() const override { return true; }

    // Same two-phase pick as Mesh::pick — uses rest-pose vertex positions.
    PickResult pick(const Ray &worldRay, const glm::mat4 &model = glm::mat4(1.f)) const;
};



 
struct VertexAnimVertex
{
    glm::vec3 position; 
    glm::vec2 uv;       
    glm::vec3 normal;   
};


struct MeshTag
{
    char tag[32];
    glm::vec3 origin = glm::vec3(0.0f);
    glm::vec3 axis[3] = 
    {
        glm::vec3(1.0f, 0.0f, 0.0f),
        glm::vec3(0.0f, 1.0f, 0.0f),
        glm::vec3(0.0f, 0.0f, 1.0f)
    };
};


// ============================================================
//  AnimatedMeshBuffer — skinned
// ============================================================
struct AnimatedVertexMeshBuffer : public IDrawable
{
    std::vector<VertexAnimVertex> vertices;
    std::vector<glm::vec3> positions;
    std::vector<uint16_t> indices;
    GLuint vao = 0, vbo = 0, ibo = 0;
    GLenum mode = GL_TRIANGLES;

    void upload();
    void update();
    void draw() const override;
    void drawRange(uint32_t start, uint32_t count) const override;
    void free();

    // IDrawable
    BoundingBox getAABB() const override { return BoundingBox{}; }
    int vertexCount() const override { return (int)vertices.size(); }
    int indexCount() const override { return (int)indices.size(); }

    VertexAnimVertex &operator[](int i) { return vertices[i]; }
    int count() const { return (int)vertices.size(); }

    AnimatedVertexMeshBuffer() = default;
    AnimatedVertexMeshBuffer(const AnimatedVertexMeshBuffer &) = delete;
    AnimatedVertexMeshBuffer &operator=(const AnimatedVertexMeshBuffer &) = delete;
    ~AnimatedVertexMeshBuffer() { free(); }
};


class VertexAnimatedMesh : public MeshBase<AnimatedVertexMeshBuffer>, public IDrawable
{
public:

   

    std::vector<glm::vec3>   framePositions;
    std::vector<std::string> frameNames;
    std::vector<MeshTag>     tags;
    int tagsPerFrame = 0;

    float currentFrame = 0.0f;

    void compute_normals();

    void upload();
    void setFrame(float frame);
    void setFrame(float frame, int startFrame, int endFrame);
    void setFrameBlended(float fromFrame, int fromStartFrame, int fromEndFrame,
                         float toFrame, int toStartFrame, int toEndFrame, float alpha);
    int findTag(const char *name) const;
    bool sampleTag(int tagIndex, float frame, glm::mat4 &out) const;
    bool sampleTag(int tagIndex, float frame, int startFrame, int endFrame, glm::mat4 &out) const;
    bool sampleTagBlended(int tagIndex,
                          float fromFrame, int fromStartFrame, int fromEndFrame,
                          float toFrame, int toStartFrame, int toEndFrame,
                          float alpha, glm::mat4 &out) const;
    bool sampleTag(const char *name, float frame, glm::mat4 &out) const;




    void draw() const override { buffer.draw(); }
    void drawRange(uint32_t s, uint32_t c) const override { buffer.drawRange(s, c); }
    BoundingBox getAABB() const override { return aabb; }
    int vertexCount() const override { return (int)buffer.vertices.size(); }
    int indexCount() const override { return (int)buffer.indices.size(); }
    int frameCount() const
    {
        return buffer.vertices.empty() ? 0 : (int)(framePositions.size() / buffer.vertices.size());
    }

    PickResult pick(const Ray &worldRay, const glm::mat4 &model = glm::mat4(1.f)) const;
};

 
