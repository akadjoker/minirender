#pragma once
#include <vector>
#include <string>
#include "glad/glad.h"
#include <glm/glm.hpp>

struct Vertex
{
    glm::vec3 position;
    glm::vec3 normal;
    glm::vec2 uv;
};

class Mesh
{
public:
    std::string name;

    ~Mesh() { destroy(); }

    void upload(const std::vector<Vertex> &verts, const std::vector<unsigned int> &idx);
    void draw() const;
    void destroy();

    int indexCount = 0;

private:
    GLuint vao = 0, vbo = 0, ebo = 0;
};
