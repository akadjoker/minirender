#pragma once
#include "Material.hpp"
#include <SDL2/SDL.h>
#include <cstddef>
#include <string>
#include <vector>
#include <unordered_map>

// ═════════════════════════════════════════════════════════════════════════════
//  Base — raw pointer cache, manager owns the memory
// ═════════════════════════════════════════════════════════════════════════════
template <typename T>
class ResourceManager
{
public:
    T *get(const std::string &name) const
    {
        auto it = cache.find(name);
        return (it != cache.end()) ? it->second : nullptr;
    }

    bool has(const std::string &name) const
    {
        return cache.count(name) > 0;
    }

    void unload(const std::string &name)
    {
        auto it = cache.find(name);
        if (it != cache.end())
        {
            delete it->second;
            cache.erase(it);
        }
    }

    void unloadAll()
    {
        for (auto &[_, ptr] : cache)
            delete ptr;
        cache.clear();
    }

    const std::unordered_map<std::string, T *> &all() const { return cache; }

protected:
    std::unordered_map<std::string, T *> cache;
};

// ═════════════════════════════════════════════════════════════════════════════
//  ShaderManager
// ═════════════════════════════════════════════════════════════════════════════
class ShaderManager : public ResourceManager<Shader>
{
public:
    static ShaderManager &instance();

    Shader *load(const std::string &name,
                 const std::string &vertPath,
                 const std::string &fragPath);

    Shader *loadFromSource(const std::string &name,
                           const std::string &vertSrc,
                           const std::string &fragSrc);

    bool reload(const std::string &name);
    void reloadAll();

private:
    ShaderManager() = default;

    struct ShaderPaths
    {
        std::string vert, frag;
    };
    std::unordered_map<std::string, ShaderPaths> paths;
};

// ═════════════════════════════════════════════════════════════════════════════
//  TextureManager
// ═════════════════════════════════════════════════════════════════════════════
struct TextureLoadOptions
{
    bool genMipmaps = true;
    bool sRGB = false;
    GLint wrapS = GL_REPEAT;
    GLint wrapT = GL_REPEAT;
    GLint filterMin = GL_LINEAR_MIPMAP_LINEAR;
    GLint filterMag = GL_LINEAR;
};

class TextureManager : public ResourceManager<Texture>
{
public:
    static TextureManager &instance();

    Texture *load(const std::string &name,
                  const std::string &path,
                  const TextureLoadOptions &opts = {});

    Texture *loadCubemap(const std::string &name,
                         const std::vector<std::string> &faces,
                         const TextureLoadOptions &opts = {});

    Texture *createFromMemory(const std::string &name,
                              int width, int height,
                              PixelType pixelType,
                              const void *data,
                              std::size_t sizeBytes,
                              const TextureLoadOptions &opts = {});

    Texture *getWhite();
    Texture *getBlack();
    Texture *getFlatNormal();
    Texture *getPattern();

private:
    TextureManager() = default;

    Texture *uploadSurface(const std::string &name,
                           SDL_Surface *surf,
                           const TextureLoadOptions &opts);

    Texture *makeSolid(const std::string &name,
                       uint8_t r, uint8_t g, uint8_t b, uint8_t a);
};

// ═════════════════════════════════════════════════════════════════════════════
//  MaterialManager
// ═════════════════════════════════════════════════════════════════════════════
class MaterialManager : public ResourceManager<Material>
{
public:
    static MaterialManager &instance();

    Material *create(const std::string &name);
    Material *clone(const std::string &srcName, const std::string &newName);

    const Material *activeMaterial() const { return active; }

private:
    MaterialManager() = default;

    const Material *active = nullptr;
};
