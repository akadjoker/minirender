#include "Node.hpp"

Node::Node(const std::string &n): name(n), type(NodeType::Node)
{
}

 