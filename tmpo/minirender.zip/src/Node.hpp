#pragma once
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <string>

class Node
{
public:
    std::string name;
    glm::vec3 position = glm::vec3(0);
    glm::vec3 scale = glm::vec3(1);
    glm::vec3 rotation = glm::vec3(0); // Euler angles em graus
  


    glm::mat4 getTransform() const
    {
        glm::mat4 t = glm::mat4(1.0f);
        t = glm::translate(t, position);
        t = glm::rotate(t, glm::radians(rotation.x), glm::vec3(1, 0, 0));
        t = glm::rotate(t, glm::radians(rotation.y), glm::vec3(0, 1, 0));
        t = glm::rotate(t, glm::radians(rotation.z), glm::vec3(0, 0, 1));
        t = glm::scale(t, scale);
        return t;
    }

 
};
