#include "Mesh.hpp"
#include <cassert>
#include <glad/glad.h>

struct AttribInfo
{
    u32 flag;
    u32 size;
};

static const AttribInfo attribTable[] = {
    {ATTRIB_POSITION, 3},
    {ATTRIB_NORMAL, 3},
    {ATTRIB_TANGENT, 3},
    {ATTRIB_COLOR3, 3},
    {ATTRIB_COLOR4, 4},
    {ATTRIB_UV0, 2},
    {ATTRIB_UV1, 2},
    {ATTRIB_UV2, 2},
    {ATTRIB_UV3, 2},
    {ATTRIB_UV4, 2},
    {ATTRIB_UV5, 2},
    {ATTRIB_UV6, 2},
    {ATTRIB_UV7, 2},
    {ATTRIB_JOINTS, 4},
    {ATTRIB_WEIGHTS, 4},
};

static constexpr u32 ATTRIB_COUNT =
    sizeof(attribTable) / sizeof(attribTable[0]);
 

Mesh::Mesh(u32 attribFlags, bool dynamic_vertex, bool indexed, bool dynamic_index)
    : isDynamicVertex(dynamic_vertex), isDynamicIndex(dynamic_index), isIndexed(indexed)
{
    glGenVertexArrays(1, &vao);
    glBindVertexArray(vao);

    for (u32 i = 0; i < ATTRIB_COUNT; i++)
    {
        u32 flag = attribTable[i].flag;
        if (!(attribFlags & flag))
            continue;

        MeshStream s;
        s.attrib = flag;
        s.size = attribTable[i].size;
        s.slot = i;

        glGenBuffers(1, &s.vbo);
        glBindBuffer(GL_ARRAY_BUFFER, s.vbo);
        glEnableVertexAttribArray(s.slot);
        glVertexAttribPointer(s.slot, s.size,
                              GL_FLOAT, GL_FALSE, 0, nullptr);
        streams.push_back(s);
    }

    if (isIndexed)
    {
        glGenBuffers(1, &ebo);
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
    }

    glBindVertexArray(0);
}

Mesh::~Mesh()
{
    for (auto &s : streams)
        glDeleteBuffers(1, &s.vbo);
    if (ebo)
        glDeleteBuffers(1, &ebo);
    glDeleteVertexArrays(1, &vao);
}

// ─────────────────────────────────────────────
// Streams
// ─────────────────────────────────────────────

MeshStream &Mesh::getStream(u32 attrib)
{
    for (auto &s : streams)
        if (s.attrib == attrib)
            return s;
    assert(false && "Stream not found");
    return streams[0]; // para evitar warning, nunca deve chegar aqui
}

bool Mesh::hasStream(u32 attrib) const
{
    for (auto &s : streams)
        if (s.attrib == attrib)
            return true;
    return false;
}

bool Mesh::needsUpdate() const
{
    if (indicesDirty)
        return true;
    for (auto &s : streams)
        if (s.dirty)
            return true;
    return false;
}

// ─────────────────────────────────────────────
// Índices
// ─────────────────────────────────────────────

void Mesh::addFace(u32 v0, u32 v1, u32 v2)
{
    indices.push_back(v0);
    indices.push_back(v1);
    indices.push_back(v2);
    indicesDirty = true;
}

void Mesh::addIndex(u32 index)
{
    indices.push_back(index);
    indicesDirty = true;
}

// ─────────────────────────────────────────────
// SubMeshes
// ─────────────────────────────────────────────

void Mesh::beginSubMesh(u32 material)
{
    SubMesh s;
    s.firstIndex = (u32)indices.size();
    s.indexCount = 0;
    s.material = material;
    submeshes.push_back(s);
}

void Mesh::endSubMesh()
{
    assert(!submeshes.empty() && "endSubMesh sem beginSubMesh");
    SubMesh &s = submeshes.back();
    s.indexCount = (u32)indices.size() - s.firstIndex;
}

// ─────────────────────────────────────────────
// Upload GPU
// ─────────────────────────────────────────────

void Mesh::update(bool cleanup)
{
    
    glBindVertexArray(vao);

    GLenum usage = isDynamicVertex ? GL_DYNAMIC_DRAW : GL_STATIC_DRAW;

    for (auto &s : streams)
    {
        if (!s.dirty)
            continue;
        glBindBuffer(GL_ARRAY_BUFFER, s.vbo);
        glBufferData(GL_ARRAY_BUFFER,
                     s.data.size() * sizeof(float),
                     s.data.data(), usage);

        if (s.attrib == ATTRIB_POSITION)
            vertexCount = (u32)(s.data.size() / s.size);

        s.dirty = false;
        if (cleanup)
        {
            s.data.clear();
            s.data.shrink_to_fit();
        }
    }

    if (isIndexed && indicesDirty)
    {
        GLenum iusage = isDynamicIndex ? GL_DYNAMIC_DRAW : GL_STATIC_DRAW;
        glBindBuffer(GL_ELEMENT_ARRAY_BUFFER, ebo);
        glBufferData(GL_ELEMENT_ARRAY_BUFFER,
                     indices.size() * sizeof(u32),
                     indices.data(), iusage);
        indexCount = (u32)indices.size();
        indicesDirty = false;
        if (cleanup)
        {
            indices.clear();
            indices.shrink_to_fit();
        }
    }

    glBindVertexArray(0);
}

// ─────────────────────────────────────────────
// Render — mesh inteira
// ─────────────────────────────────────────────

void Mesh::render()
{
    glBindVertexArray(vao);
    if (isIndexed)
        glDrawElements(GL_TRIANGLES, indexCount, GL_UNSIGNED_INT, nullptr);
    else
        glDrawArrays(GL_TRIANGLES, 0, vertexCount);
    glBindVertexArray(0);
}

void Mesh::render(int mode)
{
    glBindVertexArray(vao);
    if (isIndexed)
        glDrawElements(mode, indexCount, GL_UNSIGNED_INT, nullptr);
    else
        glDrawArrays(mode, 0, vertexCount);
    glBindVertexArray(0);
}

void Mesh::render(int mode, int count)
{
    glBindVertexArray(vao);
    if (isIndexed)
        glDrawElements(mode, count, GL_UNSIGNED_INT, nullptr);
    else
        glDrawArrays(mode, 0, count);
    glBindVertexArray(0);
}

void Mesh::render(int mode, int first, int count)
{
    glBindVertexArray(vao);
    if (isIndexed)
        glDrawElements(mode, count, GL_UNSIGNED_INT,
                       (void *)(first * sizeof(u32)));
    else
        glDrawArrays(mode, first, count);
    glBindVertexArray(0);
}

// ─────────────────────────────────────────────
// Render — submesh
// ─────────────────────────────────────────────

void Mesh::renderSubMesh(u32 index)
{
    assert(index < (u32)submeshes.size());
    const SubMesh &s = submeshes[index];
    glBindVertexArray(vao);
    glDrawElements(GL_TRIANGLES, s.indexCount, GL_UNSIGNED_INT, (void *)(s.firstIndex * sizeof(u32)));
    glBindVertexArray(0);
}

void Mesh::renderSubMesh(u32 index, int mode)
{
    assert(index < (u32)submeshes.size());
    const SubMesh &s = submeshes[index];
    glBindVertexArray(vao);
    glDrawElements(mode, s.indexCount, GL_UNSIGNED_INT,(void *)(s.firstIndex * sizeof(u32)));
    glBindVertexArray(0);
}

 
void Mesh::renderAll()
{
    if (submeshes.empty())
    {
        render();
        return;
    }
    glBindVertexArray(vao);
    for (const auto &s : submeshes)
        glDrawElements(GL_TRIANGLES, s.indexCount, GL_UNSIGNED_INT,(void *)(s.firstIndex * sizeof(u32)));
    glBindVertexArray(0);
}

void Mesh::renderAll(int mode)
{
    if (submeshes.empty())
    {
        render(mode);
        return;
    }
    glBindVertexArray(vao);
    for (const auto &s : submeshes)
        glDrawElements(mode, s.indexCount, GL_UNSIGNED_INT,(void *)(s.firstIndex * sizeof(u32)));
    glBindVertexArray(0);
}