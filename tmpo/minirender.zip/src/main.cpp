#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <glad/glad.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include "Input.hpp"
#include "Mesh.hpp"
#include "MeshManager.hpp"
#include "Texture.hpp"
#include "TextureManager.hpp"
#include "Shader.hpp"
#include "ShaderManager.hpp"
#include "Camera.hpp"
#include "Material.hpp"
#include "MaterialManager.hpp"
#include "RenderCommand.hpp"
#include "RenderQueue.hpp"

const int SCREEN_W = 1024;
const int SCREEN_H = 768;

static const char *VERT_SRC = R"(
#version 330 core
layout(location = 0) in vec3 aPos;
layout(location = 1) in vec3 aNormal;
layout(location = 2) in vec2 aUV;

out vec3 FragPos;
out vec3 Normal;
out vec2 TexCoord;

uniform mat4 u_model;
uniform mat4 u_view;
uniform mat4 u_proj;

void main() {
    vec4 world  = u_model * vec4(aPos, 1.0);
    FragPos     = world.xyz;
    Normal      = mat3(transpose(inverse(u_model))) * aNormal;
    TexCoord    = aUV;
    gl_Position = u_proj * u_view * world;
}
)";

static const char *FRAG_SRC = R"(
#version 330 core
in vec3 FragPos;
in vec3 Normal;
in vec2 TexCoord;

out vec4 FragColor;

uniform vec4      u_color;
uniform vec3      u_lightPos;
uniform vec3      u_viewPos;
uniform sampler2D u_diffuse;
uniform int       u_hasTexture;

void main() {
    vec3 base = (u_hasTexture == 1)
        ? texture(u_diffuse, TexCoord).rgb
        : u_color.rgb;

    vec3 ambient  = 0.2 * base;

    vec3 norm     = normalize(Normal);
    vec3 lightDir = normalize(u_lightPos - FragPos);
    float diff    = max(dot(norm, lightDir), 0.0);
    vec3 diffuse  = diff * base;

    vec3 viewDir  = normalize(u_viewPos - FragPos);
    vec3 halfway  = normalize(lightDir + viewDir);
    float spec    = pow(max(dot(norm, halfway), 0.0), 32.0);
    vec3 specular = 0.3 * spec * vec3(1.0);

    FragColor = vec4(ambient + diffuse + specular, u_color.a);
}
)";

// ── Render com Material ──────────────────────────────────
static void renderQueue(RenderQueue &queue, Camera &camera, const glm::vec3 &lightPos)
{
    queue.sort();

    Shader *lastShader = nullptr;
    GLuint lastTexture = 0;

    for (auto &cmd : queue.getCommands())
    {
        Technique *tech = cmd.material->getBestTechnique();
        if (!tech || tech->passes.empty())
            continue;

        Pass &pass = tech->passes[0];
        if (!pass.shader)
            continue;

        // Bind shader só se mudou
        if (pass.shader != lastShader)
        {
            pass.shader->bind();
            pass.shader->setMat4("u_view", camera.getView());
            pass.shader->setMat4("u_proj", camera.getProjection());
            pass.shader->setVec3("u_lightPos", lightPos);
            pass.shader->setVec3("u_viewPos", camera.position);
            lastShader = pass.shader;
        }

        // Bind textura só se mudou
        if (!pass.textures.empty() && pass.textures[0].texture)
        {
            GLuint texID = pass.textures[0].texture->getID();
            if (texID != lastTexture)
            {
                pass.textures[0].texture->bind(0);
                pass.shader->setInt("u_diffuse", 0);
                pass.shader->setInt("u_hasTexture", 1);
                lastTexture = texID;
            }
        }
        else
        {
            pass.shader->setInt("u_hasTexture", 0);
        }

        // Uniforms por objeto
        pass.shader->setMat4("u_model", cmd.transform);
        pass.shader->setVec4("u_color", pass.color);

        cmd.mesh->draw();
    }
}

// ────────────────────────────────────────────────────────
int main(int argc, char *argv[])
{

    // ── SDL + OpenGL ─────────────────────────────────────
    SDL_Init(SDL_INIT_VIDEO);
    IMG_Init(IMG_INIT_JPG | IMG_INIT_PNG);

    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);

    SDL_Window *window = SDL_CreateWindow(
        "Mini Pipeline",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        SCREEN_W, SCREEN_H,
        SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE);

    SDL_GLContext ctx = SDL_GL_CreateContext(window);
    SDL_GL_SetSwapInterval(1);

    // Tu usas GLES2 loader não o GL loader!
    if (!gladLoadGLES2Loader((GLADloadproc)SDL_GL_GetProcAddress))
    {
        SDL_Log("[GLAD] Failed to initialize GLAD");
        return -1;
    }

    SDL_Log("[GL]  %s", glGetString(GL_VERSION));
    SDL_Log("[GPU] %s", glGetString(GL_RENDERER));

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glViewport(0, 0, SCREEN_W, SCREEN_H);

    // ── Shaders ──────────────────────────────────────────
    Shader *shader = ShaderManager::instance().loadFromSource("main", VERT_SRC, FRAG_SRC);

    // ── Meshes ───────────────────────────────────────────
    Mesh *cube = MeshManager::instance().createCube("Cube");
    Mesh *plane = MeshManager::instance().createPlane("Ground", 20.0f, 10);

    // ── Texturas ─────────────────────────────────────────
    Texture *texWall = TextureManager::instance().load("assets/wall.jpg");
    Texture *texGrass = TextureManager::instance().load("assets/grass.jpg");

    // ── Materiais ────────────────────────────────────────
    Material *matCube = MaterialManager::instance().create("cube");
    {
        Pass &p = matCube->addPass("default");
        p.shader = shader;
        p.color = glm::vec4(1, 1, 1, 1);
        p.textures = {{texWall, 0}};
    }

    Material *matPlane = MaterialManager::instance().create("plane");
    {
        Pass &p = matPlane->addPass("default");
        p.shader = shader;
        p.color = glm::vec4(1, 1, 1, 1);
        p.textures = {{texGrass, 0}};
    }

    // ── Camera ───────────────────────────────────────────
    Camera camera;
    FreeCameraComponent cameraControl;
    camera.setAspect(SCREEN_W, SCREEN_H);

    glm::vec3 cubePositions[] = {
        {0.0f, 0.5f, 0.0f},
        {3.0f, 0.5f, -3.0f},
        {-3.0f, 0.5f, -3.0f},
        {5.0f, 0.5f, 2.0f},
        {-5.0f, 0.5f, 2.0f},
    };

    // ── Time ─────────────────────────────────────────────
    Uint64 now = SDL_GetPerformanceCounter();
    Uint64 last = 0;
    float time = 0.0f;

    Input &input = Input::instance();

    // ── Loop ─────────────────────────────────────────────
    while (!input.shouldQuit())
    {
        last = now;
        now = SDL_GetPerformanceCounter();
        float dt = (float)(now - last) / (float)SDL_GetPerformanceFrequency();
        time += dt;

        input.process();

        int w, h;
        SDL_GetWindowSize(window, &w, &h);
        glViewport(0, 0, w, h);
        camera.setAspect(w, h);

        cameraControl.update(camera, dt);

        glm::vec3 lightPos = {
            sin(time) * 5.0f,
            5.0f + cos(time) * 1.0f,
            cos(time) * 4.0f};

        glClearColor(0.15f, 0.15f, 0.2f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        // ── Submit à RenderQueue ──────────────────────────
        RenderQueue queue;

        // Plano
        glm::mat4 planeModel = glm::translate(glm::mat4(1.0f), glm::vec3(0, -1, 0));
        queue.submit(plane, matPlane, planeModel);

        // Cubos
        for (auto &pos : cubePositions)
        {
            glm::mat4 model = glm::translate(glm::mat4(1.0f), pos);
            model = glm::rotate(model, time * glm::radians(20.0f), glm::vec3(0, 1, 0));
            queue.submit(cube, matCube, model);
        }

        // ── Render ───────────────────────────────────────
        renderQueue(queue, camera, lightPos);

        SDL_GL_SwapWindow(window);
    }

    // ── Cleanup ──────────────────────────────────────────
    MaterialManager::instance().clear();
    MeshManager::instance().clear();
    TextureManager::instance().clear();
    ShaderManager::instance().clear();

    SDL_GL_DeleteContext(ctx);
    SDL_DestroyWindow(window);
    IMG_Quit();
    SDL_Quit();

    return 0;
}
