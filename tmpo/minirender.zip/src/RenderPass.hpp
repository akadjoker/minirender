#pragma once

class RenderQueue;
class Camera;

class RenderPass
{
public:
    virtual ~RenderPass() = default;
    virtual void execute(RenderQueue *queue, Camera *camera) = 0;
};
