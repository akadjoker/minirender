#include "Shader.hpp"
#include <SDL2/SDL.h>
#include <glm/gtc/type_ptr.hpp>
#include <iostream>

// ── Lê ficheiro com SDL ──────────────────────────────────
static char *readFileSDL(const std::string &path, size_t &outSize)
{
    SDL_RWops *rw = SDL_RWFromFile(path.c_str(), "rb");
    if (!rw)
    {
        SDL_Log("[Shader] Cannot open: %s — %s", path.c_str(), SDL_GetError());
        return nullptr;
    }

    Sint64 size = SDL_RWsize(rw);
    if (size <= 0)
    {
        SDL_RWclose(rw);
        return nullptr;
    }

    char *buf = new char[size + 1];
    SDL_RWread(rw, buf, 1, (size_t)size);
    buf[size] = '\0';
    SDL_RWclose(rw);

    outSize = (size_t)size;
    return buf;
}

// ── Compile ─────────────────────────────────────────────
GLuint Shader::compileStage(const char *src, GLenum type)
{
    GLuint s = glCreateShader(type);
    glShaderSource(s, 1, &src, nullptr);
    glCompileShader(s);

    GLint ok;
    glGetShaderiv(s, GL_COMPILE_STATUS, &ok);
    if (!ok)
    {
        char log[512];
        glGetShaderInfoLog(s, 512, nullptr, log);
        SDL_Log("[Shader] Compile error: %s", log);
        glDeleteShader(s);
        return 0;
    }
    return s;
}

// ── Link ────────────────────────────────────────────────
bool Shader::linkProgram(GLuint vert, GLuint frag)
{
    program = glCreateProgram();
    glAttachShader(program, vert);
    glAttachShader(program, frag);
    glLinkProgram(program);

    glDeleteShader(vert);
    glDeleteShader(frag);

    GLint ok;
    glGetProgramiv(program, GL_LINK_STATUS, &ok);
    if (!ok)
    {
        char log[512];
        glGetProgramInfoLog(program, 512, nullptr, log);
        SDL_Log("[Shader] Link error: %s", log);
        glDeleteProgram(program);
        program = 0;
        return false;
    }
    return true;
}

// ── Load from file ───────────────────────────────────────
bool Shader::loadFromFile(const std::string &vertPath, const std::string &fragPath)
{
    size_t vs, fs;
    char *vertSrc = readFileSDL(vertPath, vs);
    char *fragSrc = readFileSDL(fragPath, fs);

    if (!vertSrc || !fragSrc)
    {
        delete[] vertSrc;
        delete[] fragSrc;
        return false;
    }

    bool result = loadFromSource(vertSrc, fragSrc);

    delete[] vertSrc;
    delete[] fragSrc;
    return result;
}

// ── Load from source ─────────────────────────────────────
bool Shader::loadFromSource(const char *vertSrc, const char *fragSrc)
{
    GLuint vert = compileStage(vertSrc, GL_VERTEX_SHADER);
    GLuint frag = compileStage(fragSrc, GL_FRAGMENT_SHADER);

    if (!vert || !frag)
    {
        if (vert)
            glDeleteShader(vert);
        if (frag)
            glDeleteShader(frag);
        return false;
    }

    return linkProgram(vert, frag);
}

// ── Uniforms ─────────────────────────────────────────────
void Shader::setInt(const std::string &n, int v) const { glUniform1i(glGetUniformLocation(program, n.c_str()), v); }
void Shader::setFloat(const std::string &n, float v) const { glUniform1f(glGetUniformLocation(program, n.c_str()), v); }
void Shader::setVec2(const std::string &n, const glm::vec2 &v) const { glUniform2fv(glGetUniformLocation(program, n.c_str()), 1, glm::value_ptr(v)); }
void Shader::setVec3(const std::string &n, const glm::vec3 &v) const { glUniform3fv(glGetUniformLocation(program, n.c_str()), 1, glm::value_ptr(v)); }
void Shader::setVec4(const std::string &n, const glm::vec4 &v) const { glUniform4fv(glGetUniformLocation(program, n.c_str()), 1, glm::value_ptr(v)); }
void Shader::setMat4(const std::string &n, const glm::mat4 &v) const { glUniformMatrix4fv(glGetUniformLocation(program, n.c_str()), 1, GL_FALSE, glm::value_ptr(v)); }
