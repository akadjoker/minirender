#pragma once
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include <string>


enum class NodeType { Node, Node3D };


class Node
{
protected:
    
Node* parent = nullptr;
std::string name;
NodeType type;
std::vector<Node*> children;

public:

    
    Node(const std::string& n);
};


class Node3D : public Node
{

   public:
    glm::vec3 position;
    glm::vec3 scale;
    glm::vec3 rotation;

    Node3D(const std::string& n);

  
};

