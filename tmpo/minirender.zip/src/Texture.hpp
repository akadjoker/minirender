#pragma once
#include <string>
#include "glad/glad.h"

class Texture
{
public:
    ~Texture()
    {
        if (id)
            glDeleteTextures(1, &id);
    }

    bool load(const std::string &path);
    void bind(int slot = 0) const;

    GLuint getID() const { return id; }

private:
    GLuint id = 0;
};
