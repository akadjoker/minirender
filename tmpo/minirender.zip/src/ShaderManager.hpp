#pragma once
#include "Shader.hpp"
#include <unordered_map>
#include <string>

class ShaderManager
{
public:
    static ShaderManager &instance()
    {
        static ShaderManager inst;
        return inst;
    }

    ~ShaderManager() { clear(); }

    // Carrega de ficheiros
    Shader *load(const std::string &name,
                 const std::string &vertPath,
                 const std::string &fragPath)
    {
        if (auto *s = get(name))
            return s;

        Shader *s = new Shader();
        if (!s->loadFromFile(vertPath, fragPath))
        {
            SDL_Log("[ShaderManager] Failed to load: %s", name.c_str());
            delete s;
            return nullptr;
        }

        shaders[name] = s;
        return s;
    }

    // Cria de source inline
    Shader *loadFromSource(const std::string &name,
                           const char *vertSrc,
                           const char *fragSrc)
    {
        if (auto *s = get(name))
            return s;

        Shader *s = new Shader();
        if (!s->loadFromSource(vertSrc, fragSrc))
        {
            SDL_Log("[ShaderManager] Failed to compile: %s", name.c_str());
            delete s;
            return nullptr;
        }

        shaders[name] = s;
        return s;
    }

    Shader *get(const std::string &name)
    {
        auto it = shaders.find(name);
        return it != shaders.end() ? it->second : nullptr;
    }

    void destroy(const std::string &name)
    {
        auto it = shaders.find(name);
        if (it != shaders.end())
        {
            delete it->second;
            shaders.erase(it);
        }
    }

    void clear()
    {
        for (auto &[name, s] : shaders)
            delete s;
        shaders.clear();
    }

private:
    std::unordered_map<std::string, Shader *> shaders;
};
