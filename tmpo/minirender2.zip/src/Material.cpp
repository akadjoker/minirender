
#include "Material.hpp"

Material* Material::setTexture(const std::string& u, Texture* t)
{
    for (auto& slot : textures)
    {
        if (slot.uniform == u)
        {
            slot.texture = t;
            return this;
        }
    }
    textures.push_back({ t, u });
    return this;
}


Material *Material::setInt(const std::string &u, int v)
{
    uniforms[u] = {.type = UniformType::Int, .i = v};
    return this;
}
Material *Material::setFloat(const std::string &u, float v)
{
    uniforms[u] = {.type = UniformType::Float, .f = v};
    return this;
}
Material *Material::setVec2(const std::string &u, glm::vec2 v)
{
    uniforms[u] = {.type = UniformType::Vec2, .v2 = v};
    return this;
}
Material *Material::setVec3(const std::string &u, glm::vec3 v)
{
    uniforms[u] = {.type = UniformType::Vec3, .v3 = v};
    return this;
}
Material *Material::setVec4(const std::string &u, glm::vec4 v)
{
    uniforms[u] = {.type = UniformType::Vec4, .v4 = v};
    return this;
}
Material *Material::setMat3(const std::string &u, glm::mat3 v)
{
    uniforms[u] = {.type = UniformType::Mat3, .m3 = v};
    return this;
}
Material *Material::setMat4(const std::string &u, glm::mat4 v)
{
    uniforms[u] = {.type = UniformType::Mat4, .m4 = v};
    return this;
}
