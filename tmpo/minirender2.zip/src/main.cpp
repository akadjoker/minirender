#include <SDL2/SDL.h>
#include <SDL2/SDL_image.h>
#include <glad/glad.h>
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>

#include "Input.hpp"
#include "Camera.hpp"

const int SCREEN_W = 1024;
const int SCREEN_H = 768;


// ────────────────────────────────────────────────────────
int main(int argc, char *argv[])
{

    // ── SDL + OpenGL ─────────────────────────────────────
    SDL_Init(SDL_INIT_VIDEO);
    IMG_Init(IMG_INIT_JPG | IMG_INIT_PNG);

    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MAJOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_MINOR_VERSION, 3);
    SDL_GL_SetAttribute(SDL_GL_CONTEXT_PROFILE_MASK, SDL_GL_CONTEXT_PROFILE_CORE);
    SDL_GL_SetAttribute(SDL_GL_DOUBLEBUFFER, 1);
    SDL_GL_SetAttribute(SDL_GL_DEPTH_SIZE, 24);

    SDL_Window *window = SDL_CreateWindow(
        "Mini Pipeline",
        SDL_WINDOWPOS_CENTERED, SDL_WINDOWPOS_CENTERED,
        SCREEN_W, SCREEN_H,
        SDL_WINDOW_OPENGL | SDL_WINDOW_RESIZABLE);

    SDL_GLContext ctx = SDL_GL_CreateContext(window);
    SDL_GL_SetSwapInterval(1);

    // Tu usas GLES2 loader não o GL loader!
    if (!gladLoadGLES2Loader((GLADloadproc)SDL_GL_GetProcAddress))
    {
        SDL_Log("[GLAD] Failed to initialize GLAD");
        return -1;
    }

    SDL_Log("[GL]  %s", glGetString(GL_VERSION));
    SDL_Log("[GPU] %s", glGetString(GL_RENDERER));

    glEnable(GL_DEPTH_TEST);
    glEnable(GL_CULL_FACE);
    glCullFace(GL_BACK);
    glViewport(0, 0, SCREEN_W, SCREEN_H);

    // ── Camera ───────────────────────────────────────────
    Camera camera;
    FreeCameraComponent cameraControl;
    camera.setAspect(SCREEN_W, SCREEN_H);

    glm::vec3 cubePositions[] = {
        {0.0f, 0.5f, 0.0f},
        {3.0f, 0.5f, -3.0f},
        {-3.0f, 0.5f, -3.0f},
        {5.0f, 0.5f, 2.0f},
        {-5.0f, 0.5f, 2.0f},
    };

    // ── Time ─────────────────────────────────────────────
    Uint64 now = SDL_GetPerformanceCounter();
    Uint64 last = 0;
    float time = 0.0f;

    Input &input = Input::instance();

    // ── Loop ─────────────────────────────────────────────
    while (!input.shouldQuit())
    {
        last = now;
        now = SDL_GetPerformanceCounter();
        float dt = (float)(now - last) / (float)SDL_GetPerformanceFrequency();
        time += dt;

        input.process();

        int w, h;
        SDL_GetWindowSize(window, &w, &h);
        glViewport(0, 0, w, h);
        camera.setAspect(w, h);

        cameraControl.update(camera, dt);

        glm::vec3 lightPos = {
            sin(time) * 5.0f,
            5.0f + cos(time) * 1.0f,
            cos(time) * 4.0f};

        glClearColor(0.15f, 0.15f, 0.2f, 1.0f);
        glClear(GL_COLOR_BUFFER_BIT | GL_DEPTH_BUFFER_BIT);

        
        SDL_GL_SwapWindow(window);
    }


    SDL_GL_DeleteContext(ctx);
    SDL_DestroyWindow(window);
    IMG_Quit();
    SDL_Quit();

    return 0;
}
