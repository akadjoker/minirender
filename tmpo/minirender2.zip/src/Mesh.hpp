#pragma once
#include "Types.hpp"
#include <vector>
#include <string>
#include "glad/glad.h"
#pragma once
#include <vector>
#include <string>

struct MeshStream
{
    u32 vbo = 0;
    u32 attrib = 0;
    u32 size = 0; // floats por vértice
    u32 slot = 0; // location no shader
    bool dirty = false;
    std::vector<float> data;
};

struct SubMesh
{
    u32 firstIndex = 0;
    u32 indexCount = 0;
    u32 material = 0;
};

class Mesh
{
    u32 vao = 0;
    u32 ebo = 0;
    u32 vertexCount = 0;
    u32 indexCount = 0;
    bool isDynamicVertex = false;
    bool isDynamicIndex = false;
    bool isIndexed = true;

    std::vector<MeshStream> streams;
    std::vector<u32> indices;
    std::vector<SubMesh> submeshes;
    bool indicesDirty = false;

public:
    std::string name;

    Mesh(u32 attribFlags, bool dynamic_vertex = false,
         bool indexed = true, bool dynamic_index = false);
    ~Mesh();

    // Streams
    MeshStream &getStream(u32 attrib);
    bool hasStream(u32 attrib) const;
    bool needsUpdate() const;

    // Índices / faces
    void addFace(u32 v0, u32 v1, u32 v2);
    void addIndex(u32 index);


    void beginSubMesh(u32 material = 0);
    void endSubMesh();
    u32 subMeshCount() const { return (u32)submeshes.size(); }
    SubMesh &getSubMesh(u32 index) { return submeshes[index]; }

    // Upload para GPU
    void update(bool cleanup = false);

    // Render tudo
    void render();
    void render(int mode);
    void render(int mode, int count);
    void render(int mode, int first, int count);

    // Render submesh específico
    void renderSubMesh(u32 index);
    void renderSubMesh(u32 index, int mode);

    // Render todos os submeshes (loop simples, funciona em qualquer plataforma)
    void renderAll();
    void renderAll(int mode);
};