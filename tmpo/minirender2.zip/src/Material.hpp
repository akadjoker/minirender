#pragma once
#include "Types.hpp"
#include "glad/glad.h"
#include <SDL2/SDL.h>
#include <string>
#include <vector>
#include <unordered_map>
#include <glm/glm.hpp>
 


struct Texture
{
    GLuint id = 0;
    int width = 0;
    int height = 0;
    GLenum target = GL_TEXTURE_2D; 
    PixelType type = PixelType::RGBA;
};

struct TextureSlot 
{
    Texture*    texture = nullptr;
    std::string uniform; // "u_albedo", "u_normal"
};

class Shader
{
public:
    Shader(const std::string& n) : name(n) {}

    bool load(const std::string& vertPath, const std::string& fragPath);
    bool loadFromSource(const std::string& vertSrc, const std::string& fragSrc);

    void setInt  (const std::string& u, int v)              const;
    void setFloat(const std::string& u, float v)            const;
    void setVec3 (const std::string& u, const glm::vec3& v) const;
    void setVec4 (const std::string& u, const glm::vec4& v) const;
    void setMat4 (const std::string& u, const glm::mat4& v) const;

    GLuint   getId()      const { return id; }
    uint32_t getAttribs() const { return attribs; }

    ~Shader();

private:
    std::string name;
    uint32_t    attribs = 0;
    GLuint      id      = 0;

    mutable std::unordered_map<std::string, GLint> uniformCache;

    static bool readFile(const std::string& path, std::string& out);
    GLuint      compileSource(const std::string& src, GLenum type) const;
    void        resolveAttribs();
    GLint       getLoc(const std::string& u) const;
};



class Material
{
private:


    std::vector<TextureSlot> textures;
    std::unordered_map<std::string, UniformValue> uniforms;
    Shader *shader = nullptr;
    

public:
    std::string name;
    bool cullFace = true;
    bool blend = false;
    bool depthTest = true;
    bool depthWrite = true;

    Material *setShader(Shader *s)
    {
        shader = s;
        return this;
    }
    Material *setCullFace(bool v)
    {
        cullFace = v;
        return this;
    }
    Material *setBlend(bool v)
    {
        blend = v;
        return this;
    }
    Material *setDepthTest(bool v)
    {
        depthTest = v;
        return this;
    }
    Material *setDepthWrite(bool v)
    {
        depthWrite = v;
        return this;
    }
    Material *setTexture(const std::string &u, Texture *t);
    Material *setInt(const std::string &u, int v);
    Material *setFloat(const std::string &u, float v);
    Material *setVec2(const std::string &u, glm::vec2 v);
    Material *setVec3(const std::string &u, glm::vec3 v);
    Material *setVec4(const std::string &u, glm::vec4 v);
    Material *setMat3(const std::string &u, glm::mat3 v);
    Material *setMat4(const std::string &u, glm::mat4 v);
};
