// RenderQueue.hpp
#pragma once
#include "RenderCommand.hpp"
#include <vector>
#include <algorithm>

class RenderQueue
{
public:
    void submit(Mesh *mesh, Material *material, const glm::mat4 &transform, bool castShadows = true)
    {
        RenderCommand cmd;
        cmd.mesh = mesh;
        cmd.material = material;
        cmd.transform = transform;
        cmd.castShadows = castShadows;
        cmd.sortKey = buildSortKey(material);
        commands.push_back(cmd);
    }

    void sort()
    {
        std::sort(commands.begin(), commands.end(),
                  [](const RenderCommand &a, const RenderCommand &b)
                  {
                      return a.sortKey < b.sortKey;
                  });
    }

    void clear() { commands.clear(); }

    std::vector<RenderCommand> &getCommands() { return commands; }
    int count() const { return (int)commands.size(); }

private:
    std::vector<RenderCommand> commands;

    uint64_t buildSortKey(Material *mat)
    {
        if (!mat)
            return 0;

        // Agrupa primeiro por shader, depois por textura
        // shader ID nos bits altos → minimiza bind de shader (mais caro)
        // textura ID nos bits baixos → minimiza bind de textura
        uint32_t shaderID = mat->getShaderID();    // GLuint do shader
        uint32_t textureID = mat->getTextureID(0); // GLuint da textura slot 0

        return ((uint64_t)shaderID << 32) | (uint64_t)textureID;
    }
};
