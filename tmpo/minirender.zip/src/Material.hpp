#pragma once
#include <string>
#include <vector>
#include <cstdint>
#include "Shader.hpp"
#include "Texture.hpp"
#include <glm/glm.hpp>

enum class BlendMode
{
    Opaque,
    Alpha,
    Additive
};

// ── TextureUnit ──────────────────────────────────────────
struct TextureUnit
{
    Texture *texture = nullptr;
    int slot = 0;
};

// ── Pass ────────────────────────────────────────────────
struct Pass
{
    Shader *shader = nullptr;
    std::vector<TextureUnit> textures;
    glm::vec4 color = glm::vec4(1.0f);
    float roughness = 0.5f;
    float metallic = 0.0f;
    BlendMode blend = BlendMode::Opaque;
    bool depthTest = true;
    bool depthWrite = true;

    void bind()
    {
        // Depth
        depthTest ? glEnable(GL_DEPTH_TEST) : glDisable(GL_DEPTH_TEST);
        glDepthMask(depthWrite ? GL_TRUE : GL_FALSE);

        // Blend
        if (blend == BlendMode::Alpha)
        {
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE_MINUS_SRC_ALPHA);
        }
        else if (blend == BlendMode::Additive)
        {
            glEnable(GL_BLEND);
            glBlendFunc(GL_SRC_ALPHA, GL_ONE);
        }
        else
        {
            glDisable(GL_BLEND);
        }

        // Shader
        if (shader)
            shader->bind();

        // Texturas
        for (auto &tu : textures)
            if (tu.texture)
                tu.texture->bind(tu.slot);
    }
};

// ── Technique ───────────────────────────────────────────
struct Technique
{
    std::string name;
    std::vector<Pass> passes;
};

// ── Material ────────────────────────────────────────────
class Material
{
public:
    explicit Material(const std::string &name) : name(name) {}

    // Adiciona pass a uma técnica (cria técnica se não existir)
    Pass &addPass(const std::string &tech = "default")
    {
        Technique *t = getTechnique(tech);
        if (!t)
        {
            techniques.push_back({tech, {}});
            t = &techniques.back();
        }
        t->passes.push_back({});
        return t->passes.back();
    }

    // Devolve técnica por nome — nullptr se não existir
    Technique *getTechnique(const std::string &tech = "default")
    {
        for (auto &t : techniques)
            if (t.name == tech)
                return &t;
        return nullptr;
    }

    // Devolve primeira técnica disponível como fallback
    Technique *getBestTechnique(const std::string &preferred = "default")
    {
        Technique *t = getTechnique(preferred);
        if (t)
            return t;
        return techniques.empty() ? nullptr : &techniques[0];
    }

    // Helpers para RenderQueue sort key
    uint32_t getShaderID() const
    {
        Technique *t = const_cast<Material *>(this)->getTechnique();
        if (!t || t->passes.empty() || !t->passes[0].shader)
            return 0;
        return (uint32_t)t->passes[0].shader->getProgram();
    }

    uint32_t getTextureID(int slot = 0) const
    {
        Technique *t = const_cast<Material *>(this)->getTechnique();
        if (!t || t->passes.empty())
            return 0;
        for (auto &tu : t->passes[0].textures)
            if (tu.slot == slot && tu.texture)
                return (uint32_t)tu.texture->getID();
        return 0;
    }

    std::string name;

private:
    std::vector<Technique> techniques;
};
