#pragma once
#include <glm/glm.hpp>
#include <glm/gtc/matrix_transform.hpp>
#include "Input.hpp"

class Camera
{
public:
    glm::vec3 position = glm::vec3(0, 3, 10);
    float yaw = -90.0f;
    float pitch = -15.0f;
    float fov = 45.0f;
    float nearPlane = 0.1f;
    float farPlane = 1000.0f;

    glm::vec3 getFront() const
    {
        return glm::normalize(glm::vec3(
            cos(glm::radians(yaw)) * cos(glm::radians(pitch)),
            sin(glm::radians(pitch)),
            sin(glm::radians(yaw)) * cos(glm::radians(pitch))));
    }

    glm::vec3 getRight() const
    {
        return glm::normalize(glm::cross(getFront(), glm::vec3(0, 1, 0)));
    }

    glm::vec3 getUp() const
    {
        return glm::normalize(glm::cross(getRight(), getFront()));
    }

    glm::mat4 getView() const
    {
        return glm::lookAt(position, position + getFront(), glm::vec3(0, 1, 0));
    }

    glm::mat4 getProjection(float aspect) const
    {
        return glm::perspective(glm::radians(fov), aspect, nearPlane, farPlane);
    }

    void setAspect(int w, int h)
    {
        aspect = (float)w / (float)h;
    }

    glm::mat4 getProjection() const
    {
        return glm::perspective(glm::radians(fov), aspect, nearPlane, farPlane);
    }

private:
    float aspect = 1024.0f / 768.0f;
};

class FreeCameraComponent
{
public:
    float moveSpeed = 8.0f;
    float mouseSensitivity = 0.15f;
    float sprintMultiplier = 2.5f;

    void update(Camera &camera, float dt)
    {
        Input &input = Input::instance();

        float speed = moveSpeed * dt;
        if (input.isKey(SDL_SCANCODE_LSHIFT))
            speed *= sprintMultiplier;

        // Movimento
        if (input.isKey(SDL_SCANCODE_W))
            camera.position += camera.getFront() * speed;
        if (input.isKey(SDL_SCANCODE_S))
            camera.position -= camera.getFront() * speed;
        if (input.isKey(SDL_SCANCODE_A))
            camera.position -= camera.getRight() * speed;
        if (input.isKey(SDL_SCANCODE_D))
            camera.position += camera.getRight() * speed;
        if (input.isKey(SDL_SCANCODE_E))
            camera.position.y += speed;
        if (input.isKey(SDL_SCANCODE_Q))
            camera.position.y -= speed;

        // Rotação com botão esquerdo do rato
        if (input.isMouseDown(SDL_BUTTON_LEFT))
        {
            camera.yaw += input.getDeltaX() * mouseSensitivity;
            camera.pitch -= input.getDeltaY() * mouseSensitivity;
            camera.pitch = glm::clamp(camera.pitch, -89.0f, 89.0f);
        }
    }
};
