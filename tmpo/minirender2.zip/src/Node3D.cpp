#include "Node.hpp"

 

#include "Node.hpp"

Node3D::Node3D(const std::string &n)
    : Node(n), position(0), scale(1), rotation(0)
{
    type = NodeType::Node3D;  
}