#pragma once
#include "Mesh.hpp"
#include <vector>
#include <unordered_map>
#include <string>

class MeshManager
{
public:
    static MeshManager &instance()
    {
        static MeshManager inst;
        return inst;
    }

    ~MeshManager() { clear(); }

    Mesh *createCube(const std::string &name)
    {
        if (auto *m = get(name))
            return m;
        Mesh *m = new Mesh();
        m->name = name;
        buildCube(m);
        meshes[name] = m;
        return m;
    }

    Mesh *createPlane(const std::string &name, float size = 10.0f, int divisions = 1)
    {
        if (auto *m = get(name))
            return m;
        Mesh *m = new Mesh();
        m->name = name;
        buildPlane(m, size, divisions);
        meshes[name] = m;
        return m;
    }

    Mesh *get(const std::string &name)
    {
        auto it = meshes.find(name);
        return it != meshes.end() ? it->second : nullptr;
    }

    void destroy(const std::string &name)
    {
        auto it = meshes.find(name);
        if (it != meshes.end())
        {
            delete it->second;
            meshes.erase(it);
        }
    }

    void clear()
    {
        for (auto &[name, m] : meshes)
            delete m;
        meshes.clear();
    }

private:
    std::unordered_map<std::string, Mesh *> meshes;

    // ── Cubo ─────────────────────────────────────────────
    void buildCube(Mesh *mesh)
    {
        static const glm::vec3 normals[6] = {
            {0, 0, 1},
            {0, 0, -1},
            {-1, 0, 0},
            {1, 0, 0},
            {0, 1, 0},
            {0, -1, 0},
        };
        static const glm::vec3 faceVerts[6][4] = {
            {{-0.5f, -0.5f, 0.5f}, {0.5f, -0.5f, 0.5f}, {0.5f, 0.5f, 0.5f}, {-0.5f, 0.5f, 0.5f}},
            {{0.5f, -0.5f, -0.5f}, {-0.5f, -0.5f, -0.5f}, {-0.5f, 0.5f, -0.5f}, {0.5f, 0.5f, -0.5f}},
            {{-0.5f, -0.5f, -0.5f}, {-0.5f, -0.5f, 0.5f}, {-0.5f, 0.5f, 0.5f}, {-0.5f, 0.5f, -0.5f}},
            {{0.5f, -0.5f, 0.5f}, {0.5f, -0.5f, -0.5f}, {0.5f, 0.5f, -0.5f}, {0.5f, 0.5f, 0.5f}},
            {{-0.5f, 0.5f, 0.5f}, {0.5f, 0.5f, 0.5f}, {0.5f, 0.5f, -0.5f}, {-0.5f, 0.5f, -0.5f}},
            {{-0.5f, -0.5f, -0.5f}, {0.5f, -0.5f, -0.5f}, {0.5f, -0.5f, 0.5f}, {-0.5f, -0.5f, 0.5f}},
        };
        static const glm::vec2 uvs[4] = {{0, 0}, {1, 0}, {1, 1}, {0, 1}};

        std::vector<Vertex> verts;
        std::vector<unsigned int> idx;

        for (int f = 0; f < 6; f++)
        {
            unsigned int base = (unsigned int)verts.size();
            for (int v = 0; v < 4; v++)
                verts.push_back({faceVerts[f][v], normals[f], uvs[v]});
            idx.insert(idx.end(), {base, base + 1, base + 2, base + 2, base + 3, base});
        }

        mesh->upload(verts, idx);
    }

    // ── Plano ─────────────────────────────────────────────
    void buildPlane(Mesh *mesh, float size, int divisions)
    {
        std::vector<Vertex> verts;
        std::vector<unsigned int> idx;

        float step = size / (float)divisions;
        float half = size * 0.5f;
        int w = divisions + 1;

        for (int z = 0; z <= divisions; z++)
        {
            for (int x = 0; x <= divisions; x++)
            {
                verts.push_back({{-half + x * step, 0.0f, -half + z * step},
                                 {0.0f, 1.0f, 0.0f},
                                 {(float)x / divisions, (float)z / divisions}});
            }
        }

        for (int z = 0; z < divisions; z++)
        {
            for (int x = 0; x < divisions; x++)
            {
                unsigned int tl = z * w + x;
                unsigned int tr = tl + 1;
                unsigned int bl = tl + w;
                unsigned int br = bl + 1;
                idx.insert(idx.end(), {tl, bl, tr, tr, bl, br});
            }
        }

        mesh->upload(verts, idx);
    }
};
