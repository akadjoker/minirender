#pragma once
#include <string>
#include <glm/glm.hpp>
#include "glad/glad.h"

 

class Shader {
public:
    ~Shader() { if (program) glDeleteProgram(program); }

    // Carrega de ficheiros
    bool loadFromFile(const std::string& vertPath, const std::string& fragPath);

    // Cria de strings (para shaders inline)
    bool loadFromSource(const char* vertSrc, const char* fragSrc);

    void bind()   const { glUseProgram(program); }
    void unbind() const { glUseProgram(0); }

    void setInt  (const std::string& name, int v)             const;
    void setFloat(const std::string& name, float v)           const;
    void setVec2 (const std::string& name, const glm::vec2& v) const;
    void setVec3 (const std::string& name, const glm::vec3& v) const;
    void setVec4 (const std::string& name, const glm::vec4& v) const;
    void setMat4 (const std::string& name, const glm::mat4& v) const;

    GLuint getProgram() const { return program; }
    bool   isValid()    const { return program != 0; }

private:
    GLuint program = 0;

    GLuint compileStage(const char* src, GLenum type);
    bool   linkProgram(GLuint vert, GLuint frag);
};
