


#include "pch.h"
#include "Color.hpp"


const Color Color::WHITE;
const Color Color::GRAY     (128, 128, 128);
const Color Color::BLACK    (  0,   0,   0);
const Color Color::RED      (255,   0,   0);
const Color Color::GREEN    (  0, 255,   0);
const Color Color::BLUE     (  0,   0, 255);
const Color Color::CYAN     (  0, 255, 255);
const Color Color::MAGENTA  (255,   0, 255);
const Color Color::YELLOW   (255, 255,   0);
const Color Color::TRANSPARENT(0,   0,   0,   0);