#pragma once
#include "Mesh.hpp"
#include "Material.hpp"
#include "RenderCommand.hpp"
#include "RenderQueue.hpp"
#include <glm/glm.hpp>

class MeshRenderer
{
public:
    Mesh *mesh = nullptr;
    Material *material = nullptr;

    void submit(RenderQueue *queue, const glm::mat4 &transform)
    {
        if (!mesh || !material)
            return;
        RenderCommand cmd;
        cmd.mesh = mesh;
        cmd.material = material;
        cmd.transform = transform;
        queue->submit(cmd);
    }
};
